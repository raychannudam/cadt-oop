package Udam.Lab6.Exercise8;

public interface MoveAble {
    public void moveLeft();
    public void moveRight();
    public void moveUp();
    public void moveDown();
}
