package Udam.Lab6.Exercise3;

public abstract class MyShape {
    public abstract Double getArea();
    public abstract Double getPerimeter();
    public MyShape() {
    }
}
