package Udam.Lab6.Exercise3;

public class Main {
    public static void main(String[] args) {
        MyShape rec = new Rectangle(1.50, 2.50);
        MyShape cir = new Circle(1.50);
        System.out.println(rec);
        System.out.println(cir);
    }
}
