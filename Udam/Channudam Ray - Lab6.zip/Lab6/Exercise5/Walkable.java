package Udam.Lab6.Exercise5;

public interface Walkable {
    public void walkLeft();
    public void walkRight();
    public void Forward();
    public void Backward();
}
