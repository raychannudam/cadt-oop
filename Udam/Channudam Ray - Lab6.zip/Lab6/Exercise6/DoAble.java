package Udam.Lab6.Exercise6;

public interface DoAble {
    public void doThis();
    public void doThat();

}
