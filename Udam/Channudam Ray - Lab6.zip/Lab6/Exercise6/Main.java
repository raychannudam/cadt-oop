package Udam.Lab6.Exercise6;

public class Main {
    public static void main(String[] args) {
        DoAble human1 = new Human("Udam", 19, "Khmer");
        DoAble human2 = new Human("Dara", 20, "Khmer");
        System.out.println(human1);
        System.out.println(human2);
    }
}
