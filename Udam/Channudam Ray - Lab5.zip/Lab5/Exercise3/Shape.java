package Udam.Lab5.Exercise3;

public class Shape {
    public double getArea(){
        return 0.0d;
    }
    public double getPerimeter(){
        return 0.0d;
    }
}
