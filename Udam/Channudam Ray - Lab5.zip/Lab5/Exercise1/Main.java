package Udam.Lab5.Exercise1;

public class Main {
    public static void main(String[] args) {
        Animal a1  = new Animal();
        a1.cry();
        a1.walk();

        Animal a2 = new Cat();
        a2.cry();
        a2.walk();

        Animal a3  = new Dog();
        a3.cry();
        a3.walk();

        Cat c1 = new Cat();
        c1.cry();
        c1.walk();

        Dog d1 = new Dog();
        d1.cry();
        d1.walk();
    }
}
