package Udam.Lab5.Exercise1;

public class Cat extends Animal {
    public void walk(){
        System.out.println("cat is walking");
    }
    public void cry(){
        System.out.println("cat is crying");
    }
}
