package Udam.Lab5.Exercise1;

public class Animal {
    public void walk(){
        System.out.println("animal is walking");
    }
    public void cry(){
        System.out.println("animal is crying");
    }
}
