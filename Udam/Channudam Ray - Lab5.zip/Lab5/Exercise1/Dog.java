package Udam.Lab5.Exercise1;

public class Dog extends Animal {
    public void walk(){
        System.out.println("dog is walking");
    }
    public void cry(){
        System.out.println("dog is crying");
    }
}
